"""
Abstract RKM level class.

@author: HENRI DE PLAEN
@copyright: KU LEUVEN
@license: MIT
@date: March 2021
"""

# import rkm._src.level.Linear as Linear
# import rkm._src.level.Level as Level
